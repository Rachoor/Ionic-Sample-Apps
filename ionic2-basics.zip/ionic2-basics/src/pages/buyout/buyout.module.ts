import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BuyoutPage } from './buyout';

@NgModule({
  declarations: [
    BuyoutPage,
  ],
  imports: [
    IonicPageModule.forChild(BuyoutPage),
  ],
})
export class BuyoutPageModule {}
