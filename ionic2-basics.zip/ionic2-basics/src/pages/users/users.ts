import { UserPage } from './user/user';
import { NavController } from 'ionic-angular';
import { Component } from '@angular/core';

@Component({
  selector: 'page-users',
  templateUrl: 'users.html',
})
export class UsersPage {
  constructor(private navCtrl: NavController) {}
  onLoadUser(name) {
    this.navCtrl.push(UserPage, name);
  }

  ionViewCanEnter() {
    
  }
}
