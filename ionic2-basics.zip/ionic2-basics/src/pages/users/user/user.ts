import { NavParams, NavController } from 'ionic-angular';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'page-user',
  templateUrl: 'user.html',
})
export class UserPage implements OnInit {
  name: string;

  constructor(private navparams: NavParams, private navctrl: NavController) {}
  ngOnInit() {
    this.name = this.navparams.data;
  }
  onGoBack() {
    this.navctrl.popToRoot();
  }
}
