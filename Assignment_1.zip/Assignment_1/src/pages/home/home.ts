import { UyoutPage } from './../uyout/uyout';
import { ShopPage } from '../shop/shop';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  constructor(public navCtrl: NavController) {}

  onNavStart() {
    this.navCtrl.push(ShopPage);
  }
  onShop () {
    this.navCtrl.push(UyoutPage);
  }
}
