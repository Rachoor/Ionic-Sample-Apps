import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UyoutPage } from './uyout';

@NgModule({
  declarations: [
    UyoutPage,
  ],
  imports: [
    IonicPageModule.forChild(UyoutPage),
  ],
})
export class UyoutPageModule {}
