import { ShopPage } from '../shop/shop';
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-uyout',
  templateUrl: 'uyout.html',
})
export class UyoutPage {
  constructor(public navCtrl: NavController, public navParams: NavParams) {}
  onShop() {
    this.navCtrl.push(ShopPage);
  }
}
